package es.hiberus.com.to_do_list_espresso_test.model

data class Task(val name: String, var isCompleted: Boolean = false)
